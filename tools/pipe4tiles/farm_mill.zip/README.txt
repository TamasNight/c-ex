# Credit
Tileset made by u/TommyCazzanelli based on aveontrainer’s work: https://www.deviantart.com/aveontrainer/art/Farm-Exterior-Tileset-878600837

# File Format
The tileset is already tiled to fit hack rom requirements. To use it in an RPGMaker project, open it in render.html to recreate the original image, disable the grid, save it, and resize it x2.

# Useful file
render.html is a small JS application that allows you, using the JSON map, to rebuild the original image from the tiles and also provides instructions on how to do the same in the tileset editor.